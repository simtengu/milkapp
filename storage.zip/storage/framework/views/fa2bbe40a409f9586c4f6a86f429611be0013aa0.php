               
<?php $__env->startSection('content'); ?>
                    <div class="container-fluid">
                        <h1 class="mt-4 text-app">Dashboard</h1>
                        <div class="row">
                            <div class="col-xl-3 col-md-6">
                                <div class="card bg-primary text-white mb-4">
                                    <div class="card-body">View Reports</div>
                                    <div class="card-footer d-flex align-items-center justify-content-between">
                                        <a class="small text-white stretched-link" href="<?php echo e(route('general.report')); ?>">Visit</a>
                                        <div class="small text-white"><i class="fas fa-angle-right"></i></div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xl-3 col-md-6">
                                <div class="card bg-warning text-white mb-4">
                                    <div class="card-body">Print Reports</div>
                                   
                                    <div class="card-footer d-flex align-items-center justify-content-between">
                                        <a class="small text-white stretched-link" href="<?php echo e(route('print_reports')); ?>">View Details</a>
                                        <div class="small text-white"><i class="fas fa-angle-right"></i></div>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="col-md-10">
                            <?php if(Session()->has('income_removed')): ?>
                                <div class="alert alert-success my-3">
                                    <button type="button" class="close" data-dismiss="alert">×</button>
                                    <p><?php echo e(Session('income_removed')); ?></p>
                                </div>
                            <?php endif; ?>
                            </div>
                        </div>
  
                        <div class="card mb-4">
                            <div class="card-header d-flex justify-content-between">
                               <h5 class="text-times text-app">Mapato ya leo</h5>
                               <h5 class="text-times text-primary"><?php echo e(date('d-m-Y')); ?></h5>
                            </div>
                            <div class="card-body">
                            <div class="row justify-content-start mb-3">
                                <div class="mx-3 my-1">    
                                <button id="kwaChupaBtn" class="btn btn-app text-times font-18">kwa chupa</button>
                                </div>

                                <div class="mx-3 my-1">
                                <button id="kwaLitaBtn" class="btn btn-app text-times font-18">kwa rejareja</button>    
                                </div>

                                <div class="mx-3 my-1">
                                <button id="kwaYogurtBtn" class="btn btn-app text-times font-18">kwa Yogurt</button>    
                                </div>
                               
                            </div>
                                <div id="kwaChupaTable" class="table-responsive">
                                    <p class="font-17 text-times">mauzo kwa chupa</p>
                                    <table class="table table-bordered table-striped" id="dataTable" width="100%" cellspacing="0">
                                        <thead>
                                            <tr>
                                                <th>Sno:</th>
                                                <th>Aina ya maziwa</th>
                                                <th>Chupa</th>
                                                <th>Bei(Tsh)</th>
                                                <th>Idadi</th>
                                                <th>Kiasi(Tsh)</th>
                                                <th>time</th>
                                                <th class="text-center"><a href="<?php echo e(route('income.index')); ?>" class="text-success text-times font-17">Ongeza</a></th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                    
                                     <?php if(count($bottle_incomes)): ?>
                                       <?php  $count = 1; ?>
                                        <?php $__currentLoopData = $bottle_incomes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $income): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($count); ?></td>
                                                <td><?php echo e($income->milk_type); ?></td>
                                                <td><?php echo e($income->bottle_capacity); ?></td>
                                                <td><?php echo e(number_format($income->price)); ?></td>
                                                <td><?php echo e($income->quantity); ?></td>
                                                <td><?php echo e(number_format($income->amount)); ?></td>
                                                <td><?php echo e($income->created_at->diffForHumans()); ?></td>
                                                <td class="text-center">
                                                    <a href="<?php echo e(route('edit_bottle_income',$income->id)); ?>" class="text-underline text-app">actions</a>
                                                </td>
                                            </tr>
                                            <?php  $count = $count + 1; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php else: ?>
                                              <tr><td colspan="8" class="text-app text-center"> hakuna taarifa</td></tr>
                                     <?php endif; ?>
                                  
                                        </tbody>
                                    </table>
                                    
                                <?php if(count($bottle_incomes)): ?>
                                <div>
                                  <?php echo e($bottle_incomes->links()); ?>

                                </div>
                                <?php endif; ?>

                                </div>

                                <div id="kwaLitaTable" class="table-responsive" style="display: none;">
                                    <p class="font-17 text-times">mauzo kwa rejareja</p>
                                    <table class="table table-striped table-bordered" id="dataTable" width="100%" cellspacing="0">
                                       <thead>
                                            <tr>
                                                <th>Sno:</th>
                                                <th>Aina ya maziwa</th>
                                                <th>Ujazo</th>
                                                <th>Bei(Tsh)</th>
                                                <th>Idadi</th>
                                                <th>Kiasi(Tsh)</th>
                                                <th class="text-center"><a href="<?php echo e(route('income.index')); ?>" class="text-success text-times font-17">Ongeza</a></th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                    
                                     <?php if(count($litre_incomes)): ?>
                                       <?php  $counter = 1; ?>
                                        <?php $__currentLoopData = $litre_incomes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $income): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($counter); ?></td>
                                                <td><?php echo e($income->milk_type); ?></td>
                                                <td><?php echo e($income->volume); ?></td>
                                                <td><?php echo e(number_format($income->price)); ?></td>
                                                <td><?php echo e($income->quantity); ?></td>
                                                <td><?php echo e(number_format($income->amount)); ?></td>
                                                <td class="text-center">
                                                    <a href="<?php echo e(route('edit_litre_income',$income->id)); ?>" class="text-underline text-app">actions</a>
                                                </td>
                                            </tr>
                                            <?php  $counter = $counter + 1; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                        <?php else: ?>
                                              <tr><td colspan="7" class="text-app text-center"> hakuna taarifa</td></tr>
                                     <?php endif; ?>
                                  
                                        </tbody>
                                    </table>
                                    
                                <?php if(count($litre_incomes)): ?>
                                <div>
                                  <?php echo e($litre_incomes->links()); ?>

                                </div>
                                <?php endif; ?>
                                </div>


                                <div id="kwaYogurtTable" class="table-responsive" style="display: none;">
                                    <p class="font-17 text-times">mauzo kwa yogurt</p>
                                    <table class="table table-striped table-bordered" id="dataTable" width="100%" cellspacing="0">
                                       <thead>
                                            <tr>
                                                <th>Sno:</th>
                                                <th>Aina/Ujazo</th>
                                                <th>Bei(Tsh)</th>
                                                <th>Idadi</th>
                                                <th>Kiasi(Tsh)</th>
                                                <th class="text-center"><a href="<?php echo e(route('income.index')); ?>" class="text-success text-times font-17">Ongeza</a></th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                    
                                     <?php if(count($yogurt_incomes)): ?>
                                       <?php  $j = 1; ?>
                                        <?php $__currentLoopData = $yogurt_incomes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $income): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($j); ?></td>
                                                <td><?php echo e($income->capacity); ?></td>
                                                <td><?php echo e(number_format($income->price)); ?></td>
                                                <td><?php echo e($income->quantity); ?></td>
                                                <td><?php echo e(number_format($income->amount)); ?></td>
                                                <td class="text-center">
                                                    <a href="<?php echo e(route('edit_yogurt_income',$income->id)); ?>" class="text-underline text-app">actions</a>
                                                </td>
                                            </tr>
                                            <?php  $j = $j + 1; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                        <?php else: ?>
                                              <tr><td colspan="6" class="text-app text-center"> hakuna taarifa</td></tr>
                                     <?php endif; ?>
                                  
                                        </tbody>
                                    </table>
                                    
                                <?php if(count($yogurt_incomes)): ?>
                                <div>
                                  <?php echo e($yogurt_incomes->links()); ?>

                                </div>
                                <?php endif; ?>
                                </div>

                            </div>
                        </div>
                        <div class="card mt-3">
                            <div class="card-header d-flex justify-content-between">
                                <h5 class="text-times text-app">Matumizi ya leo</h5>
                                <h5 class="text-times text-primary"><?php echo e(date('d-m-Y')); ?></h5>
                            </div>
                            <div class="card-body">
                                <div id="matumiziyaleo_div" class="table-responsive">
                                    <table class="table table-bordered table-striped" width="100%" cellspacing="0">
                                        <thead>
                                            <tr>
                                                <th>Sno:</th>
                                                <th>Lengo/kusudi</th>
                                                <th>Wahusika</th>
                                                <th>Kiasi(Tsh)</th>
                                                <th class="text-center"><a href="<?php echo e(route('expense.index')); ?>" class="text-success text-times font-17">Ongeza</a></th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                    
                                     <?php if(count($expenses)): ?>
                                       <?php  $count = 1; ?>
                                        <?php $__currentLoopData = $expenses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $expense): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($count); ?></td>
                                                <td><?php echo e($expense->purpose); ?></td>
                                                <td><?php echo e($expense->to_whom); ?></td>
                                                <td><?php echo e(number_format($expense->amount)); ?></td>
                                                <td class="text-center">
                                                    <a href="<?php echo e(route('expense.edit',$expense->id)); ?>" class="text-underline text-app">actions</a>
                                                </td>
                                            </tr>
                                            <?php  $count = $count + 1; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php else: ?>
                                              <tr><td colspan="6" class="text-app text-center"> hakuna taarifa</td></tr>
                                     <?php endif; ?>
                                  
                                        </tbody>
                                    </table>
                                    
                                <?php if(count($expenses)): ?>
                                <div>
                                  <?php echo e($expenses->links()); ?>

                                </div>
                                <?php endif; ?>
                                </div> 
                            </div>
                        </div>
                    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
  <script type="text/javascript">
      $(document).ready(function(){

//hide and show kwa chupa and kwa lita tables............................
  $("#kwaChupaBtn").click(function(){
    $("#kwaChupaTable").show();
    $("#kwaLitaTable").hide();
    $("#kwaYogurtTable").hide();
  });

  $("#kwaLitaBtn").click(function(){
    $("#kwaLitaTable").show();
    $("#kwaChupaTable").hide();
    $("#kwaYogurtTable").hide();
  });

  $("#kwaYogurtBtn").click(function(){
    $("#kwaLitaTable").hide();
    $("#kwaChupaTable").hide();
    $("#kwaYogurtTable").show();
  });

         $("#entries_select").change(function(){
          var range = $(this).val();
          if (range != "") {
            window.location.href  = "<?php echo e(url('/administrator')); ?>"+"/"+range;
          }
         });
//searching user basing on their email...................................................
         $("#searchName").on('keyup', function(){
           var item  = $(this).val().trim();
           if (item.length > 1) {
               
               $.ajax({
                url: "<?php echo e(url('/admin_email_fetch')); ?>"+"/"+item,
                method:"GET",
                success: function(rs){
                 $("#results_ul").html(rs);
                },
                error: function(){
                    console.log("something went wrong");
                }
               })
           }else{
             $("#results_ul").html("");
           }
         });

         $(document).click(function(){
             $("#results_ul").html("");
         });
          $("#results_ul").click(function(e){
             e.stopPropagation();
          });
      });


  </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\milkApp\resources\views/admin/index.blade.php ENDPATH**/ ?>