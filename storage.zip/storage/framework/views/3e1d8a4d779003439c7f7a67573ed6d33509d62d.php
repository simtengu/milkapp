
<?php $__env->startSection('content'); ?>
    <div class="container-fluid">


        <div class="card my-4">
            <div class="card-header">
                <h3 class="text-times text-app">Filters</h3>
                <div class="d-flex flex-wrap">
                    <div>
                        <a href="<?php echo e(route('general.report')); ?>" class="btn btn-sm btn-outline-secondary mx-1">Today</a>
                    </div>
                   <div style="position: relative">
                       <button id="date_btn" class="btn btn-sm btn-outline-secondary mx-1">Date</button>
                       <div style="display:none; position: absolute;left:0px;top:31px;z-index:100;" class="border rounded shadow bg-light" id="date_div">
                         <div style="border-radius: 5px 5px 0px 0px; background: linear-gradient(rgb(147, 56, 212),indigo) " class="d-flex justify-content-center align-items-center p-1">
                             <p class="text-light text-times font-17 text-capitalize mt-1">pick date</p>
                         </div>
                         
                         <div class="p-2">
                             <form method="POST" action="<?php echo e(route('date.report')); ?>" class="form">
                                <?php echo csrf_field(); ?>
                                  <div class="form-group">
                                      <input name="date" class="form-control" type="date" required>
                                      <button class="btn btn-app-outline mt-2 btn-sm btn-block">submit</button>
                                  </div>
                                  
                              </form>
                         </div>
                       </div>
                  </div>
                   <div style="position: relative">
                       <button id="date_range_btn" class="btn btn-sm btn-outline-secondary mx-1">Date range</button>
                       <div style="display:none; position: absolute;left:0px;top:31px;z-index:100;" class="border rounded shadow bg-light" id="date_range_div">
                         <div style="border-radius: 5px 5px 0px 0px; background: linear-gradient(rgb(147, 56, 212),indigo) " class="d-flex justify-content-center align-items-center p-1">
                             <p class="text-light text-times font-17 text-capitalize mt-1">select range</p>
                         </div>
                         
                         <div class="p-2">
                             <form method="POST" action="<?php echo e(route('date_range.report')); ?>" class="form">
                                 <?php echo csrf_field(); ?>
                                    <div class="form-group">
                                        <label for="from_date">From</label>
                                      <input name="from_date" class="form-control" id="from_date" type="date" required>
                                    </div>
                                    <div class="form-group">
                                        <label for="to_date">To</label>
                                      <input name="to_date" class="form-control" id="to_date" type="date" required>
                                    </div>

                                    <button class="btn btn-app-outline btn-sm btn-block">submit</button>
                                  
                              </form>
                         </div>
                       </div>
                  </div>
                  <div>
                      <a href="<?php echo e(route('all.report')); ?>" class="btn btn-sm btn-outline-secondary mx-1">All</a>
                 </div> 
              
                </div>
            </div>
            <div class="card-body">
                 <?php if(isset($today_filter)): ?>
                     <h4 class="text-dark text-times"><?php echo e($today_filter); ?></h4>
                 <?php endif; ?>

                 <?php if(isset($all_filter)): ?>
                     <h4 class="text-dark text-times"><?php echo e($all_filter); ?></h4>
                 <?php endif; ?>

                 <?php if(isset($date_filter)): ?>
                     <h4 class="text-dark text-times"><?php echo e($date_filter); ?></h4>
                 <?php endif; ?>

                 <?php if(isset($date_range_filter)): ?>
                     <h4 class="text-dark text-times"><?php echo e($date_range_filter); ?></h4>
                 <?php endif; ?>
                <div class="row justify-content-start mb-5">
                    <div class="mx-3 my-1">
                        <button id="mapato_btn" class="btn btn-app text-times font-18">Mapato</button>
                    </div>

                    <div class="mx-3 my-1">
                        <button id="matumizi_btn" class="btn btn-app text-times font-18">Matumizi</button>
                    </div>

                    <div class="mx-3 my-1">
                        <button id="analysis_btn" class="btn btn-app text-times font-18">Analysis</button>
                    </div>

                </div>
                
                <div id="mapato_container" class="row">
                    <div class="col-12">
                        <h3 class="text-app font-weight-bold text-uppercase">mapato</h3>
                        <h5 class="text-times ml-3 font-weight-bold">Jumla ya mapato: <span
                                class="text-app"><?php echo e(number_format($total_income)); ?> Tsh</span> </h5>
        
                    
                    <hr>
                    <div style="flex-wrap: wrap" class="d-flex  justify-content-start my-3">
                    <div class="mx-3 my-1">
                        <button id="mapato_kwa_chupa_btn" class="btn text-app font-weight-bold text-times font-16 bg-light-grey">kwa chupa</button>
                    </div>

                    <div class="mx-3 my-1">
                        <button id="mapato_kwa_lita_btn" class="btn text-app font-weight-bold text-times font-16 bg-light-grey">kwa rejareja</button>
                    </div>

                    <div class="mx-3 my-1">
                        <button id="mapato_kwa_yogurt_btn" class="btn text-app font-weight-bold text-times font-16 bg-light-grey">kwa yogurt</button>
                    </div>

                </div>          
                    </div>
                    <div id="kwa_chupa_div" class="col-12">
                        <div class="table-responsive">
                            <div class="d-flex justify-content-between">
                                <p class="font-17 text-times text-capitalize">mauzo kwa chupa</p>
                               <p class="ml-3 text-times font-17">Jumla: <span
                                    class="text-app font-weight-bold"><?php echo e(number_format($total_bottle_income)); ?> Tsh</span>
                               </p>
                            </div>
                            <table class="table table-bordered table-striped" id="dataTable" width="100%" cellspacing="0">
                                <thead>
                                    <tr>
                                        <th>Sno:</th>
                                        <th>Aina ya maziwa</th>
                                        <th>Chupa</th>
                                        <th>Bei(Tsh)</th>
                                        <th>Idadi</th>
                                        <th>Kiasi(Tsh)</th>
                                        <th>Tarehe</th>
                                        <th>username</th>
                                        <th class="text-center"><a href="<?php echo e(route('income.index')); ?>" class="text-success text-times font-17">Ongeza</a></th>
                                    </tr>
                                </thead>
                                <tbody>

                                    <?php if(count($bottle_incomes)): ?>
                                        <?php $count = 1; ?>
                                        <?php $__currentLoopData = $bottle_incomes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $income): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($count); ?></td>
                                                <td><?php echo e($income->milk_type); ?></td>
                                                <td><?php echo e($income->bottle_capacity); ?></td>
                                                <td><?php echo e($income->price); ?></td>
                                                <td><?php echo e($income->quantity); ?></td>
                                                <td><?php echo e($income->amount); ?></td>
                                                <td><?php echo e($income->created_at->toDateString()); ?></td>
                                                <td><?php echo e($income->added_by); ?></td>
                                                <td class="text-center">
                                                    <a href="<?php echo e(route('edit_bottle_income',$income->id)); ?>" class="text-underline text-app">actions</a>
                                                </td>
                                            </tr>
                                            <?php $count = $count + 1; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php else: ?>
                                        <tr>
                                            <td colspan="9" class="text-app text-center"> hakuna taarifa</td>
                                        </tr>
                                    <?php endif; ?>

                                </tbody>
                            </table>
                            
                           
                                    <div>
                                      <?php echo e($bottle_incomes->links()); ?>

                                    </div>
                          

                        </div>

                    </div>

                    <div style="display: none" id="kwa_lita_div" class="col-12">
                        <div class="table-responsive">
                            <div class="d-flex justify-content-between">
                               <p class="font-17 text-times text-capitalize">mauzo kwa rejareja</p>
                               <p class="ml-3 text-times font-17">Jumla: <span
                                   class="text-app font-weight-bold"><?php echo e(number_format($total_litre_income)); ?> Tsh</span>
                               </p>
                            </div>

                            <table class="table table-striped table-bordered" id="dataTable" width="100%" cellspacing="0">
                                <thead>
                                    <tr>
                                        <th>Sno:</th>
                                        <th>Aina ya maziwa</th>
                                        <th>Ujazo</th>
                                        <th>Bei(Tsh)</th>
                                        <th>Idadi</th>
                                        <th>Kiasi(Tsh)</th>
                                        <th>Tarehe</th>
                                        <th>username</th>
                                        <th class="text-center"><a href="<?php echo e(route('income.index')); ?>" class="text-success text-times font-17">Ongeza</a></th>
                                    </tr>
                                </thead>
                                <tbody>

                                    <?php if(count($litre_incomes)): ?>
                                        <?php $counter = 1; ?>
                                        <?php $__currentLoopData = $litre_incomes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $income): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($counter); ?></td>
                                                <td><?php echo e($income->milk_type); ?></td>
                                                <td><?php echo e($income->volume); ?></td>
                                                <td><?php echo e($income->price); ?></td>
                                                <td><?php echo e($income->quantity); ?></td>
                                                <td><?php echo e($income->amount); ?></td>
                                                <td><?php echo e($income->created_at->toDateString()); ?></td>
                                                <td><?php echo e($income->added_by); ?></td>
                                                <td class="text-center">
                                                    <a href="<?php echo e(route('edit_litre_income',$income->id)); ?>" class="text-underline text-app">actions</a>
                                                </td>
                                            </tr>
                                            <?php $counter = $counter + 1; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    <?php else: ?>
                                        <tr>
                                            <td colspan="9" class="text-app text-center"> hakuna taarifa</td>
                                        </tr>
                                    <?php endif; ?>

                                </tbody>
                            </table>
                            
                           
                                    <div>
                                      <?php echo e($litre_incomes->links()); ?>

                                    </div>

                        </div>

                    </div>
                    
                    <div style="display: none" id="kwa_yogurt_div" class="col-12">
                        <div class="table-responsive">
                            <div class="d-flex justify-content-between">
                               <p class="font-17 text-times text-capitalize">mauzo ya yogurt</p>
                               <p class="ml-3 text-times font-17">Jumla: <span
                                    class="text-app font-weight-bold"><?php echo e(number_format($total_yogurt_income)); ?> Tsh</span> 
                               </p>
                            </div>

                            <table class="table table-striped table-bordered" id="dataTable" width="100%" cellspacing="0">
                                <thead>
                                    <tr>
                                        <th>Sno:</th>
                                        <th>Aina/Ujazo</th>
                                        <th>Bei(Tsh)</th>
                                        <th>Idadi</th>
                                        <th>Kiasi(Tsh)</th>
                                        <th>Tarehe</th>
                                        <th>username</th>
                                        <th class="text-center"><a href="<?php echo e(route('income.index')); ?>" class="text-success text-times font-17">Ongeza</a></th>
                                    </tr>
                                </thead>
                                <tbody>

                                    <?php if(count($yogurt_incomes)): ?>
                                        <?php $j = 1; ?>
                                        <?php $__currentLoopData = $yogurt_incomes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $income): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($j); ?></td>

                                                <td><?php echo e($income->capacity); ?></td>
                                                <td><?php echo e($income->price); ?></td>
                                                <td><?php echo e($income->quantity); ?></td>
                                                <td><?php echo e($income->amount); ?></td>
                                                <td><?php echo e($income->created_at->toDateString()); ?></td>
                                                <td><?php echo e($income->added_by); ?></td>
                                                <td class="text-center">
                                                    <a href="<?php echo e(route('edit_yogurt_income',$income->id)); ?>" class="text-underline text-app">actions</a>
                                                </td>
                                            </tr>
                                            <?php $j = $j + 1; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    <?php else: ?>
                                        <tr>
                                            <td colspan="8" class="text-app text-center"> hakuna taarifa</td>
                                        </tr>
                                    <?php endif; ?>

                                </tbody>
                            </table>
                            
                           
                                    <div>
                                      <?php echo e($yogurt_incomes->links()); ?>

                                    </div>
                        </div>

                    </div>

                </div>

                <div id="matumizi_container" style="display: none;">
                    <div class="table-responsive">
                        <h3 class="text-app font-weight-bold text-uppercase">matumizi</h3>
                        <h5 class="text-times ml-3 font-weight-bold">Jumla ya matumizi: <span
                                class="text-app"><?php echo e(number_format($total_expense)); ?> Tsh</span> </h5>
                        <table class="table table-striped table-bordered" id="dataTable" width="100%" cellspacing="0">
                            <thead>
                                <tr>
                                    <th>Sno:</th>
                                    <th>lengo/kusudi</th>
                                    <th>kiasi(Tsh)</th>
                                    <th>wahusika</th>
                                    <th>Tarehe</th>
                                    <th>Username</th>
                                    <th class="text-center"><a href="<?php echo e(route('expense.index')); ?>" class="text-success text-times font-17">Ongeza</a></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $i = 1; ?>
                                <?php $__empty_1 = true; $__currentLoopData = $expenses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $expense): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr>
                                        <td><?php echo e($i); ?></td>
                                        <td><?php echo e($expense->purpose); ?></td>
                                        <td><?php echo e(number_format($expense->amount)); ?></td>
                                        <td><?php echo e($expense->to_whom); ?></td>
                                        <td><?php echo e($expense->created_at->toDateString()); ?></td>
                                        <td><?php echo e($expense->added_by); ?></td>
                                                <td class="text-center">
                                                    <a href="<?php echo e(route('expense.edit',$expense->id)); ?>" class="text-underline text-app">actions</a>
                                                </td>
                                    </tr>
                                    <?php $i = $i + 1; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr>
                                        <td colspan="7" class="text-center"> <p class="text-app">Bado hakuna taarifa</p> </td>
                                    </tr>
                                <?php endif; ?>

                            </tbody>
                        </table>
                            
                           
                                    <div>
                                      <?php echo e($expenses->links()); ?>

                                    </div>

                    </div>
                </div>
                <div style="display: none;" id="analysis_container">
                    <div class="card" style="display: inline-block !important">
                        <div class="card-header">
                            <h2 class="text-app text-times">ANALYSIS</h2>
                        </div>
                        <div class="card-body">

                            <h5 class=" text-times">Jumla ya mapato: <span class="text-app font-weight-bold"><?php echo e(number_format($total_income)); ?> Tsh</span> </h5>
                            <h5 class=" text-times">Jumla ya matumizi: <span class="text-app font-weight-bold"><?php echo e(number_format($total_expense)); ?> Tsh</span> </h5>
                            <hr>
                            <div class="d-flex align-items-center justify-content-between mt-2 card-footern mt-2">
                                <h5 class="text-app  text-times">Status:</h5>
                                  <?php if($total_income > $total_expense): ?>
                                      <h5 class="text-success text-times">+ <?php echo e(number_format($total_income-$total_expense)); ?> Tsh</h5>
                                      <button class="btn btn-outline-success btn-sm mb-1 font-weight-bold">vizuri</button>
                                  <?php else: ?>
                                      <h5 class="text-danger text-times"> <?php echo e(number_format($total_income-$total_expense)); ?> Tsh</h5>
                                      <button class="btn btn-outline-danger btn-sm mb-1 font-weight-bold">vibaya</button>
                                  <?php endif; ?>  
                               
                            </div>
                        </div>

                    </div>
                </div>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script>
    $(document).ready(function() {
        //hide and show report sections ............................
        $("#mapato_btn").click(function() {
            $("#mapato_container").show();
            $("#matumizi_container").hide();
            $("#analysis_container").hide();
        });

        $("#matumizi_btn").click(function() {
            $("#matumizi_container").show();
            $("#mapato_container").hide();
            $("#analysis_container").hide();
        });

        $("#analysis_btn").click(function() {
            $("#analysis_container").show();
            $("#matumizi_container").hide();
            $("#mapato_container").hide();
        });

        //hide and show mapato sections...............
        $("#mapato_kwa_chupa_btn").click(function() {
             $("#kwa_chupa_div").show();
             $("#kwa_lita_div").hide();
             $("#kwa_yogurt_div").hide();
        })

        $("#mapato_kwa_lita_btn").click(function() {
             $("#kwa_chupa_div").hide();
             $("#kwa_lita_div").show();
             $("#kwa_yogurt_div").hide();
        })

        $("#mapato_kwa_yogurt_btn").click(function() {
             $("#kwa_chupa_div").hide();
             $("#kwa_lita_div").hide();
             $("#kwa_yogurt_div").show();
        })


        $("#date_btn").click(function (e) {
            $("#date_div").toggle();
             e.stopPropagation();
        })

        $("#date_range_btn").click(function (e) {
            $("#date_range_div").toggle();
           e.stopPropagation();
        })

        $(document).click(function(){
         $("#date_div").hide();
         $("#date_range_div").hide();
        });

        $("#date_div").click(function(e){
           e.stopPropagation();
        })
        $("#date_range_div").click(function(e){
           e.stopPropagation();
        })
    });

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\milkApp\resources\views/admin/reports/income.blade.php ENDPATH**/ ?>